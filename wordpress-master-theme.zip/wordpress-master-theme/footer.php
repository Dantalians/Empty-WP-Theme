</div><!-- / end page container, begun in the header -->


<footer>
	
</footer>

<?php wp_footer(); ?>

</body>
</html>
