<?php get_header(); // This fxn gets the header.php file and renders it ?>



	
	
<?php get_footer(); // This fxn gets the footer.php file and renders it ?>
